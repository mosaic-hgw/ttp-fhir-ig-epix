# Parameters-QueryPossibleMatches-response-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-QueryPossibleMatches-response-example-1",
  "parameter" : [{
    "name" : "match",
    "part" : [{
      "name" : "matchItem",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "52",
        "meta" : {
          "versionId" : "1",
          "lastUpdated" : "2021-06-17T08:28:03.200+02:00",
          "source" : "dummy_safe_source",
          "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/epix/Patient"]
        },
        "active" : true,
        "name" : [{
          "family" : "xxxxx",
          "given" : ["Stefanie"]
        }],
        "gender" : "male",
        "birthDate" : "1962-12-17"
      }
    },
    {
      "name" : "matchItem",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "53",
        "meta" : {
          "versionId" : "1",
          "lastUpdated" : "2021-06-17T08:28:24.180+02:00",
          "source" : "dummy_safe_source",
          "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/epix/Patient"]
        },
        "active" : true,
        "name" : [{
          "family" : "xxxxx",
          "given" : ["Stefanie"]
        }],
        "gender" : "male",
        "birthDate" : "1962-12-16"
      }
    },
    {
      "name" : "matchScore",
      "valueDecimal" : 0.965
    },
    {
      "name" : "matchResult",
      "valueDecimal" : 0.952
    },
    {
      "name" : "linkId",
      "valueInteger" : 5654986
    },
    {
      "name" : "comment",
      "valueString" : "Dieser Match wurde manuell durchgeführt!"
    }]
  }]
}

```
