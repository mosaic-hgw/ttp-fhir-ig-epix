# Implementation Guide E-PIX - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* **Implementation Guide E-PIX**

## Implementation Guide E-PIX

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/epix/ImplementationGuide/ths-greifswald.ttp-fhir-gw.epix | *Version*:2026.2.0-rc |
| Active as of 2026-09-22 | *Computable Name*:IGTTPFHIRGatewayEPIX |

# FHIR-Support für Record Linkage und Identitätsmanagement

Stand 19.09.2026

Die Softwarelösungen E-PIX, gPAS und gICS werden in zahlreichen Forschungseinrichtungen und Projekten für die Realisierung von Treuhandstellen-Services (THS) eingesetzt. Um die Verwendung dieser Lösungen in FHIR-basierten Infrastrukturen zu unterstützen, werden ausgewählte THS-Funktionalitäten in durch FHIR-basierte Operations, Profile, Erweiterungen und Terminologien realisiert.

Diese werden in entsprechenden [Implementierungsleitfäden](https://www.ths-greifswald.de/fhir) themenspezifisch beschrieben und zahlreiche Details erläutert.

Der vorliegende **Implementation Guide E-PIX** setzt den Fokus auf Operations, Profile und Extensions, die für [E-PIX](https://www.ths-greifswald.de/e-pix/fhir) relevant sind.

### Endpunkt

Der FHIR-Endpunkt (`base`) für das Record Linkage und Identitätsmanagement ist

**`http[s]://\<host\>:\<port\>/ttp-fhir/fhir/epix`**

 ![](assets/images/fhirgw-epix.png) 

### Package

Das automatisch erzeugte Package (TGZ) steht als Download zur Verfügung unter: [Link](package.tgz).

### Implementierung

Peter Penndorf, Martin Bialke, Christoper Hampf, Frank Michael Moser

### Autoren

Martin Bialke, Stefan Lang

### Kontakt

kontakt-ths (at) med.uni-greifswald.de

