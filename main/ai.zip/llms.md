# ths-greifswald.ttp-fhir-gw.epix#2026.1.0: null

## Pages

* [Implementation Guide E-PIX](index.md)
* [Suche nach Personen und Identitäten](Suche.md)
* [Artifacts Summary](artifacts.md)
* [Extensions](Extensions.md)
* [Allgemein](Allgemein.md)
* [Terminologie](Terminologie.md)

## Resources

### Resource Profiles

* [Patient](StructureDefinition-Patient.md)
* [Person](StructureDefinition-Person.md)

### Extensions

* [Custom IDAT Values](StructureDefinition-CustomIdatValues.md)

### ImplementationGuides

* [IGTTPFHIRGatewayEPIX](index.md)

### OperationDefinitions

* [addPatient](OperationDefinition-AddPatient.md)
* [addPossibleMatch](OperationDefinition-AddPossibleMatch.md)
* [assignIdentity](OperationDefinition-AssignIdentity.md)
* [assignIdentityByIdentifier](OperationDefinition-AssignIdentityByIdentifier.md)
* [queryPossibleMatches](OperationDefinition-QueryPossibleMatches.md)
* [removePossibleMatches](OperationDefinition-RemovePossibleMatches.md)
* [setReferenceIdentity](OperationDefinition-SetReferenceIdentity.md)
* [updatePatient](OperationDefinition-UpdatePatient.md)

### Examples

* [AssignIdentityByIdentifier-response-example1 (OperationOutcome)](OperationOutcome-AssignIdentityByIdentifier-response-example1.md)
* [OperationOutcome-AssignIdentity-response-example-1 (OperationOutcome)](OperationOutcome-OperationOutcome-AssignIdentity-response-example-1.md)
* [OperationOutcome-RemovePossibleMatches-response-example-1 (OperationOutcome)](OperationOutcome-OperationOutcome-RemovePossibleMatches-response-example-1.md)
* [Parameters-AddPatient-request-example-1 (Parameters)](Parameters-Parameters-AddPatient-request-example-1.md)
* [Parameters-AddPatient-response-example-1 (Parameters)](Parameters-Parameters-AddPatient-response-example-1.md)
* [Parameters-AddPossibleMatch-request-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatch-request-example-1.md)
* [Parameters-AddPossibleMatch-response-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatch-response-example-1.md)
* [Parameters-AssignIdentity-request-example-1 (Parameters)](Parameters-Parameters-AssignIdentity-request-example-1.md)
* [Parameters-AssignIdentityByIdentifier-request-example-1 (Parameters)](Parameters-Parameters-AssignIdentityByIdentifier-request-example-1.md)
* [Parameters-QueryPossibleMatches-request-example-1 (Parameters)](Parameters-Parameters-QueryPossibleMatches-request-example-1.md)
* [Parameters-QueryPossibleMatches-response-example-1 (Parameters)](Parameters-Parameters-QueryPossibleMatches-response-example-1.md)
* [Parameters-RemovePossibleMatches-request-example-1 (Parameters)](Parameters-Parameters-RemovePossibleMatches-request-example-1.md)
* [Parameters-SetReferenceIdentity-request-example-1 (Parameters)](Parameters-Parameters-SetReferenceIdentity-request-example-1.md)
* [Parameters-SetReferenceIdentity-response-example-1 (Parameters)](Parameters-Parameters-SetReferenceIdentity-response-example-1.md)
* [Parameters-UpdatePatient-request-example-1 (Parameters)](Parameters-Parameters-UpdatePatient-request-example-1.md)
* [Parameters-UpdatePatient-response-example-1 (Parameters)](Parameters-Parameters-UpdatePatient-response-example-1.md)
* [Patient-example-1 (Patient)](Patient-Patient-example-1.md)
* [Patient-example-2 (Patient)](Patient-Patient-example-2.md)
* [Person-example-1 (Person)](Person-Person-example-1.md)
