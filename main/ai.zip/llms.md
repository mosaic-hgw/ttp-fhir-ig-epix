# ths-greifswald.ttp-fhir-gw.epix#2026.2.0-rc: null

## Pages

* [Implementation Guide E-PIX](index.md)
* [Suche nach Personen und Identitäten](Suche.md)
* [Extensions](Extensions.md)
* [Artifacts Summary](artifacts.md)
* [Allgemein](Allgemein.md)
* [Terminologie](Terminologie.md)

## Resources

### CodeSystems

* [Match Creation Type CodeSystem](CodeSystem-MatchCreationTypeCS.md)
* [Match Priority CodeSystem](CodeSystem-MatchPriorityCS.md)

### ValueSets

* [Match Creation Type ValueSet](ValueSet-MatchCreationTypeVS.md)
* [Match Priority ValueSet](ValueSet-MatchPriorityVS.md)

### Resource Profiles

* [Patient](StructureDefinition-Patient.md)
* [Person](StructureDefinition-Person.md)
* [Match Parameters Profile](StructureDefinition-match-parameters-profile.md)

### Extensions

* [Custom IDAT Values](StructureDefinition-CustomIdatValues.md)

### ImplementationGuides

* [IGTTPFHIRGatewayEPIX](index.md)

### OperationDefinitions

* [addPatient](OperationDefinition-AddPatient.md)
* [addPossibleMatchForIdentity](OperationDefinition-AddPossibleMatchForIdentity.md)
* [addPossibleMatchForPerson](OperationDefinition-AddPossibleMatchForPerson.md)
* [assignIdentity](OperationDefinition-AssignIdentity.md)
* [assignIdentityByIdentifier](OperationDefinition-AssignIdentityByIdentifier.md)
* [queryPossibleMatches](OperationDefinition-QueryPossibleMatches.md)
* [removePossibleMatches](OperationDefinition-RemovePossibleMatches.md)
* [setReferenceIdentity](OperationDefinition-SetReferenceIdentity.md)
* [updatePatient](OperationDefinition-UpdatePatient.md)

### Examples

* [Bundle-QueryPossibleMatches-response-example-1 (Bundle)](Bundle-Bundle-QueryPossibleMatches-response-example-1.md)
* [AssignIdentityByIdentifier-response-example1 (OperationOutcome)](OperationOutcome-AssignIdentityByIdentifier-response-example1.md)
* [OperationOutcome-AssignIdentity-response-example-1 (OperationOutcome)](OperationOutcome-OperationOutcome-AssignIdentity-response-example-1.md)
* [OperationOutcome-RemovePossibleMatches-response-example-1 (OperationOutcome)](OperationOutcome-OperationOutcome-RemovePossibleMatches-response-example-1.md)
* [Parameters-AddPatient-request-example-1 (Parameters)](Parameters-Parameters-AddPatient-request-example-1.md)
* [Parameters-AddPatient-response-example-1 (Parameters)](Parameters-Parameters-AddPatient-response-example-1.md)
* [Parameters-AddPossibleMatchForIdentity-request-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatchForIdentity-request-example-1.md)
* [Parameters-AddPossibleMatchForIdentity-response-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatchForIdentity-response-example-1.md)
* [Parameters-AddPossibleMatchForPerson-request-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatchForPerson-request-example-1.md)
* [Parameters-AddPossibleMatchForPerson-response-example-1 (Parameters)](Parameters-Parameters-AddPossibleMatchForPerson-response-example-1.md)
* [Parameters-AssignIdentity-request-example-1 (Parameters)](Parameters-Parameters-AssignIdentity-request-example-1.md)
* [Parameters-AssignIdentityByIdentifier-request-example-1 (Parameters)](Parameters-Parameters-AssignIdentityByIdentifier-request-example-1.md)
* [Parameters-MatchParametersProfile-example-1 (Parameters)](Parameters-Parameters-MatchParametersProfile-example-1.md)
* [Parameters-QueryPossibleMatches-request-example-1 (Parameters)](Parameters-Parameters-QueryPossibleMatches-request-example-1.md)
* [Parameters-RemovePossibleMatches-request-example-1 (Parameters)](Parameters-Parameters-RemovePossibleMatches-request-example-1.md)
* [Parameters-SetReferenceIdentity-request-example-1 (Parameters)](Parameters-Parameters-SetReferenceIdentity-request-example-1.md)
* [Parameters-SetReferenceIdentity-response-example-1 (Parameters)](Parameters-Parameters-SetReferenceIdentity-response-example-1.md)
* [Parameters-UpdatePatient-request-example-1 (Parameters)](Parameters-Parameters-UpdatePatient-request-example-1.md)
* [Parameters-UpdatePatient-response-example-1 (Parameters)](Parameters-Parameters-UpdatePatient-response-example-1.md)
* [Patient-example-1 (Patient)](Patient-Patient-example-1.md)
* [Patient-example-2 (Patient)](Patient-Patient-example-2.md)
* [Person-example-1 (Person)](Person-Person-example-1.md)
