# removePossibleMatches - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **removePossibleMatches**

## OperationDefinition: removePossibleMatches 

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/OperationDefinition/epix/RemovePossibleMatches | *Version*:2026.2.0-rc |
| Draft as of 2026-09-16 | *Computable Name*:RemovePossibleMatches |

 
Entfernt Possible Matches anhand von LinkIds. 

Unterstützt ab v2026.2.0

## Zweck

Entfernt Possible Matches.

## Voraussetzung

Verwendete Parameter-Werte müssen im E-PIX bekannt sein.

## Aufruf und Rückgabe

Die bereitgestellte Funktionalität kann per POST-Request aufgerufen werden. Die erforderlichen Angaben werden per POST-BODY in Form von [FHIR Parameters](https://www.hl7.org/fhir/parameters.html) übermittelt.

`<HOST>:<PORT>/ttp-fhir/fhir/epix/$removePossibleMatches`

Der Funktionsaufruf liefert eine OperationOutcome-Ressource zurück.

Im Erfolgsfall wird der HTTP Statuscode 200 zurückgegeben.

Im Fehlerfall wird einer der folgenden HTTP Statuscodes in Verbindung mit einer OperationOutcome-Ressource zurückgegeben:

* 400: Fehlende oder fehlerhafte Parameter.
* 401: Fehlende Authentifizierung oder Autorisierung.
* 404: Parameter mit unbekanntem Inhalt.
* 422: Fehlende oder falsche Patienten-Attribute.

## Beispiel

* [Request-Body](Parameters-Parameters-RemovePossibleMatches-request-example-1.md)
* [Rückmeldung](OperationOutcome-OperationOutcome-RemovePossibleMatches-response-example-1.md)



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "RemovePossibleMatches",
  "url" : "https://ths-greifswald.de/fhir/OperationDefinition/epix/RemovePossibleMatches",
  "version" : "2026.2.0-rc",
  "name" : "RemovePossibleMatches",
  "title" : "removePossibleMatches",
  "status" : "draft",
  "kind" : "operation",
  "date" : "2026-09-16",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "description" : "Entfernt Possible Matches anhand von LinkIds.",
  "affectsState" : true,
  "code" : "removePossibleMatches",
  "comment" : "(Mögliche) Matches von Identitäten entfernen.",
  "system" : true,
  "type" : false,
  "instance" : false,
  "parameter" : [{
    "name" : "linkId",
    "use" : "in",
    "min" : 1,
    "max" : "*",
    "documentation" : "Link-ID eines zu löschen Matches.",
    "type" : "integer"
  },
  {
    "name" : "comment",
    "use" : "in",
    "min" : 0,
    "max" : "1",
    "documentation" : "Anmerkung zum Löschvorgang",
    "type" : "string"
  },
  {
    "name" : "return",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "Rückinformation zum Löschvorgang.",
    "type" : "OperationOutcome"
  }]
}

```
