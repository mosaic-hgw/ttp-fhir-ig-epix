# OperationOutcome-AssignIdentity-response-example-1 - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **OperationOutcome-AssignIdentity-response-example-1**

## Example OperationOutcome: OperationOutcome-AssignIdentity-response-example-1

### Issues

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Severity** | **Code** | **Diagnostics** |
| * | Information | Informational Note | identity assigned and possible match resolved. |



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "OperationOutcome-AssignIdentity-response-example-1",
  "issue" : [{
    "severity" : "information",
    "code" : "informational",
    "diagnostics" : "identity assigned and possible match resolved."
  }]
}

```
