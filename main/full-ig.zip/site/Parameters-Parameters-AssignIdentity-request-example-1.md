# Parameters-AssignIdentity-request-example-1 - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Parameters-AssignIdentity-request-example-1**

## Example Parameters: Parameters-AssignIdentity-request-example-1



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-AssignIdentity-request-example-1",
  "parameter" : [{
    "name" : "linkId",
    "valueInteger" : 86
  },
  {
    "name" : "identityReference",
    "valueId" : "252"
  },
  {
    "name" : "comment",
    "valueString" : "Nachforschungen haben ergeben, dass die Zuordung so korrekt ist."
  }]
}

```
