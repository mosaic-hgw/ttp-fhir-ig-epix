# Parameters-SetReferenceIdentity-response-example-1 - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Parameters-SetReferenceIdentity-response-example-1**

## Example Parameters: Parameters-SetReferenceIdentity-response-example-1



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-SetReferenceIdentity-response-example-1",
  "parameter" : [{
    "name" : "mpiPerson",
    "resource" : {
      "resourceType" : "Person",
      "id" : "52",
      "meta" : {
        "lastUpdated" : "2021-06-17T08:28:03.200+02:00",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/epix/Person"]
      },
      "identifier" : [{
        "system" : "https://ths-greifswald.de/fhir/epix/identifier/MPI",
        "value" : "1001000000066"
      }],
      "managingOrganization" : {
        "identifier" : {
          "value" : "MIRACUM"
        }
      },
      "active" : true,
      "link" : [{
        "target" : {
          "reference" : "Patient/52"
        }
      },
      {
        "target" : {
          "reference" : "Patient/53"
        },
        "assurance" : "level4"
      }]
    }
  },
  {
    "name" : "identity",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "52",
      "meta" : {
        "versionId" : "1",
        "lastUpdated" : "2021-06-17T08:28:03.200+02:00",
        "source" : "dummy_safe_source",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/epix/Patient"]
      },
      "active" : true,
      "name" : [{
        "family" : "xxxxx",
        "given" : ["Stefanie"]
      }],
      "gender" : "male",
      "birthDate" : "1962-12-17"
    }
  },
  {
    "name" : "identity",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "53",
      "meta" : {
        "versionId" : "1",
        "lastUpdated" : "2021-06-17T08:28:24.180+02:00",
        "source" : "dummy_safe_source",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/epix/Patient"]
      },
      "active" : true,
      "name" : [{
        "family" : "xxxxx",
        "given" : ["Stefanie"]
      }],
      "gender" : "male",
      "birthDate" : "1962-12-16"
    }
  }]
}

```
