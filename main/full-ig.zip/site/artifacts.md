# Artifacts Summary - v2026.2.0-rc

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.2.0-rc - ci-build  

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Operation Definitions 

These are custom operations that can be supported by and/or invoked by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [addPatient](OperationDefinition-AddPatient.md) | Fügt eine oder mehrere Patientenidentitäten hinzu. |
| [addPossibleMatchForIdentity](OperationDefinition-AddPossibleMatchForIdentity.md) | Fügt einen Match zu einer Person anhand von IdentityIds einer Domäne hinzu. |
| [addPossibleMatchForPerson](OperationDefinition-AddPossibleMatchForPerson.md) | Fügt einen Match zu einer Person anhand von MPIs einer Domäne hinzu. |
| [assignIdentity](OperationDefinition-AssignIdentity.md) | Verschiebt die Zuordnung einer Identität zu einer Person (MPI-Eintrag) auf eine andere Person, um eine erkannte Dublette (Match Result) zu beheben. |
| [assignIdentityByIdentifier](OperationDefinition-AssignIdentityByIdentifier.md) | Verschiebt die Zuordnung einer Identität zu einer Person (MPI-Eintrag) auf eine andere Person. Selektionsparameter ist ein Identifier der Identität. |
| [queryPossibleMatches](OperationDefinition-QueryPossibleMatches.md) | Gibt possible Matches des E-PIX zurück. Begrenzung auf eine spezifische Domäne und/oder eine spezifische Person (MPI-Eintrag) ist möglich. |
| [removePossibleMatches](OperationDefinition-RemovePossibleMatches.md) | Entfernt Possible Matches anhand von LinkIds. |
| [setReferenceIdentity](OperationDefinition-SetReferenceIdentity.md) | Ändert die Referenz-Identität einer vorhandenen Person (MPI-Eintrag), d.h. diejenigen Daten einer Person, die primäre Gültigkeit haben sollen. |
| [updatePatient](OperationDefinition-UpdatePatient.md) | Aktualisiert Patienten-Identitäten eines MPI-Eintrags. |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Match Parameters Profile](StructureDefinition-match-parameters-profile.md) | Match informationen zu zwei Identitäten inklusive der betroffenden Identitäten, Score, MatchResult und LinkId des Matches |
| [Patient](StructureDefinition-Patient.md) | Patienten-Identität (Variante/Schreibweise) einer realen Person (vgl. auch MPI Eintrag, Person-Profil). |
| [Person](StructureDefinition-Person.md) | Allgemeines Personen-Profil. Repräsentiert die reale Person (MPI Eintrag), mit beliebig vielen Varianten/Schreibweisen. Letztere werden als Patienten-Identitäten abgebildet (=> Patient-Profil). Die Referenz-Identität wird als aktuell korrekte Variante festgelegt und durch die Angabe von link.assurance='level4' repräsentiert. Es existiert immer genau 1 Link mit diesem Assurance-Level. |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Custom IDAT Values](StructureDefinition-CustomIdatValues.md) | Set von bis zu zehn individualisierbaren Werten zur Dokumentation von personenidentifizierenden Daten im E-PIX |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Match Creation Type ValueSet](ValueSet-MatchCreationTypeVS.md) | ValueSet aller zugelassenen Erstellungsarten eines Matches. |
| [Match Priority ValueSet](ValueSet-MatchPriorityVS.md) | ValueSet zur Priorisierung und Statussteuerung von Matches. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Match Creation Type CodeSystem](CodeSystem-MatchCreationTypeCS.md) | Codes zur Kennzeichnung, wie ein Match erzeugt wurde. |
| [Match Priority CodeSystem](CodeSystem-MatchPriorityCS.md) | Priorität der Bearbeitung eines Matches. |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [AssignIdentityByIdentifier-response-example1](OperationOutcome-AssignIdentityByIdentifier-response-example1.md) |  |
| [Beispiel Bundle Response für Operation QueryPossibleMatches](Bundle-Bundle-QueryPossibleMatches-response-example-1.md) | Suchergebnis-Bundle mit einer MatchParametersProfile-Instanz. |
| [Beispiel Request für Operation QueryPossibleMatches](Parameters-Parameters-QueryPossibleMatches-request-example-1.md) | Parameters-Ressource für den Aufruf der Operation per HTTP-POST. |
| [Beispiel-Instanz für MatchParametersProfile](Parameters-Parameters-MatchParametersProfile-example-1.md) | Eine konkrete Instanz des MatchParametersProfile mit Beispielwerten. |
| [Beispiel-Instanz für MatchParametersProfile AddPossibleMatchForIdentity](Parameters-Parameters-AddPossibleMatchForIdentity-response-example-1.md) | Eine konkrete Instanz des MatchParametersProfile mit Beispielwerten. |
| [Beispiel-Instanz für MatchParametersProfile AddPossibleMatchForPerson](Parameters-Parameters-AddPossibleMatchForPerson-response-example-1.md) | Eine konkrete Instanz des MatchParametersProfile mit Beispielwerten. |
| [OperationOutcome-AssignIdentity-response-example-1](OperationOutcome-OperationOutcome-AssignIdentity-response-example-1.md) |  |
| [OperationOutcome-RemovePossibleMatches-response-example-1](OperationOutcome-OperationOutcome-RemovePossibleMatches-response-example-1.md) |  |
| [Parameters-AddPatient-request-example-1](Parameters-Parameters-AddPatient-request-example-1.md) |  |
| [Parameters-AddPatient-response-example-1](Parameters-Parameters-AddPatient-response-example-1.md) |  |
| [Parameters-AddPossibleMatchForIdentity-request-example-1](Parameters-Parameters-AddPossibleMatchForIdentity-request-example-1.md) |  |
| [Parameters-AddPossibleMatchForPerson-request-example-1](Parameters-Parameters-AddPossibleMatchForPerson-request-example-1.md) |  |
| [Parameters-AssignIdentity-request-example-1](Parameters-Parameters-AssignIdentity-request-example-1.md) |  |
| [Parameters-AssignIdentityByIdentifier-request-example-1](Parameters-Parameters-AssignIdentityByIdentifier-request-example-1.md) |  |
| [Parameters-RemovePossibleMatches-request-example-1](Parameters-Parameters-RemovePossibleMatches-request-example-1.md) |  |
| [Parameters-SetReferenceIdentity-request-example-1](Parameters-Parameters-SetReferenceIdentity-request-example-1.md) |  |
| [Parameters-SetReferenceIdentity-response-example-1](Parameters-Parameters-SetReferenceIdentity-response-example-1.md) |  |
| [Parameters-UpdatePatient-request-example-1](Parameters-Parameters-UpdatePatient-request-example-1.md) |  |
| [Parameters-UpdatePatient-response-example-1](Parameters-Parameters-UpdatePatient-response-example-1.md) |  |
| [Patient-example-1](Patient-Patient-example-1.md) |  |
| [Patient-example-2](Patient-Patient-example-2.md) |  |
| [Person-example-1](Person-Person-example-1.md) |  |

