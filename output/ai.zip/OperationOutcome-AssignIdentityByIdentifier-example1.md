# AssignIdentityByIdentifier-example1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "AssignIdentityByIdentifier-example1",
  "issue" : [
    {
      "severity" : "information",
      "code" : "informational",
      "diagnostics" : "identity moved."
    }
  ]
}

```
