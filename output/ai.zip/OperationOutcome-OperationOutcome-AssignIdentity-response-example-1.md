# OperationOutcome-AssignIdentity-response-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "OperationOutcome-AssignIdentity-response-example-1",
  "issue" : [
    {
      "severity" : "information",
      "code" : "informational",
      "diagnostics" : "match resolved, identity moved."
    }
  ]
}

```
