# Parameters-AssignIdentity-request-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-AssignIdentity-request-example-1",
  "parameter" : [
    {
      "name" : "comment",
      "valueString" : "Nachforschungen haben ergeben, dass die Zuordnug so korrekt ist."
    },
    {
      "name" : "linkId",
      "valueInteger" : 5654986
    },
    {
      "name" : "identityReference",
      "valueReference" : {
        "reference" : "Patient/52"
      }
    }
  ]
}

```
