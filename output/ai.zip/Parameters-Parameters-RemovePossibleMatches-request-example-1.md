# Parameters-RemovePossibleMatches-request-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "Parameters-RemovePossibleMatches-request-example-1",
  "parameter" : [
    {
      "name" : "domain",
      "valueString" : "MIRACUM",
      "part" : [
        {
          "name" : "comment",
          "valueString" : "Dieser Match war völliger Unsinn!"
        }
      ]
    },
    {
      "name" : "linkId",
      "valueInteger" : 5654986
    }
  ]
}

```
