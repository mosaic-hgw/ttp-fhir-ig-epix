# AssignIdentityByIdentifier-response-example1 - v2026.1.0



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "AssignIdentityByIdentifier-response-example1",
  "issue" : [
    {
      "severity" : "information",
      "code" : "informational",
      "details" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/operation-outcome",
            "code" : "MSG_UPDATED"
          }
        ]
      },
      "diagnostics" : "Identity assigned."
    }
  ]
}

```
