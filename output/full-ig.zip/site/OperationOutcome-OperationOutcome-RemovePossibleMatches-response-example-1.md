# OperationOutcome-RemovePossibleMatches-response-example-1 - v2026.1.0



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "OperationOutcome-RemovePossibleMatches-response-example-1",
  "issue" : [
    {
      "severity" : "information",
      "code" : "informational",
      "diagnostics" : "removed 1 possible match(es)."
    }
  ]
}

```
