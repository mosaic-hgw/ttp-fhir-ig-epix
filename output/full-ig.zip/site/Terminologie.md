# Terminologie - v2026.1.0

